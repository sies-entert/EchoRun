import json
import pygame
from pygame.color import THECOLORS

SETTINGS = "settings.json"


def load_settings():
    """Загружает настройки из файла JSON."""
    with open(SETTINGS, "r") as f:
        return json.load(f)


def save_settings(settings):
    """Сохраняет настройки в файл JSON."""
    with open(SETTINGS, "w") as f:
        json.dump(settings, f, indent=4)


def update_settings_resolution(config, new_resolution_key=None, switch_theme=False):
    """
    Обновляет настройки для указанного разрешения и темы.
    
    Args:
        config (dict): Текущая конфигурация настроек.
        new_resolution_key (str): Ключ нового разрешения.
        switch_theme (bool): Если True, переключить тему.
    
    Returns:
        dict: Обновленная конфигурация настроек.
    """
    # Обработка разрешения экрана
    if new_resolution_key:
        if new_resolution_key in config["resolution"]:
            config["current_resolution"] = new_resolution_key

            # Автоматически обновляем шрифт и размеры кнопок
            font_key = f"f{new_resolution_key}"
            button_key = f"b{new_resolution_key}"

            if font_key in config["font_size"]:
                config["font_resolution"] = font_key
            else:
                print(f"Размер шрифта для разрешения '{new_resolution_key}' не найден.")

            if button_key in config["button_size"]:
                config["button_WuH"] = button_key
            else:
                print(f"Размер кнопок для разрешения '{new_resolution_key}' не найден.")

    # Обработка темы
    if switch_theme:
        themes = list(config["themes"].keys())
        current_theme_index = themes.index(config["theme"])
        next_theme_index = (current_theme_index + 1) % len(themes)
        config["theme"] = themes[next_theme_index]

    # Сохраняем изменения
    save_settings(config)
    return config


def settings_menu(screen, config):
    """
    Меню настроек для игры. Позволяет переключать тему и разрешение.
    
    Args:
        screen: Pygame экран для отображения меню.
        config: Словарь с настройками игры.
    
    Returns:
        dict: Обновленные настройки.
    """
    # Загрузка начальных размеров кнопок и шрифта
    button_width, button_height = config["button_size"][config["button_WuH"]]
    font_size = config["font_size"][config["font_resolution"]]
    font = pygame.font.SysFont("comic-sans", font_size)

    running = True
    while running:
        # Обрабатываем события
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                theme_button_rect = pygame.Rect(
                    screen.get_width() // 2 - button_width // 2,
                    screen.get_height() // 2 - button_height - 20,
                    button_width,
                    button_height,
                )
                resolution_button_rect = pygame.Rect(
                    screen.get_width() // 2 - button_width // 2,
                    screen.get_height() // 2 + 20,
                    button_width,
                    button_height,
                )

                if theme_button_rect.collidepoint(event.pos):
                    # Меняем тему
                    config = update_settings_resolution(config, switch_theme=True)
                elif resolution_button_rect.collidepoint(event.pos):
                    # Меняем разрешение
                    resolutions = list(config["resolution"].keys())
                    current_resolution_index = resolutions.index(config["current_resolution"])
                    next_resolution_index = (current_resolution_index + 1) % len(resolutions)
                    config = update_settings_resolution(config, new_resolution_key=resolutions[next_resolution_index])

                    # Обновляем размеры экрана, кнопок и шрифта
                    new_resolution = config["resolution"][config["current_resolution"]]
                    screen = pygame.display.set_mode(new_resolution)
                    button_width, button_height = config["button_size"][config["button_WuH"]]
                    font_size = config["font_size"][config["font_resolution"]]
                    font = pygame.font.SysFont("comic-sans", font_size)

        # Получаем параметры текущей темы
        theme = config["theme"]
        theme_settings = config["themes"][theme]
        SCREENBACKGROUND = theme_settings["SCREENBACKGROUND"]
        MENUBACKGROUND = theme_settings["MENUBACKGROUND"]
        FONTCOLOR = theme_settings["FONTCOLOR"]
        BUTTONLINE = theme_settings["BUTTONOUTLINE"]

        # Обновляем фон экрана
        screen.fill(SCREENBACKGROUND)

        # Кнопка смены темы
        theme_button_rect = pygame.Rect(
            screen.get_width() // 2 - button_width // 2,
            screen.get_height() // 2 - button_height - 20,
            button_width,
            button_height,
        )
        pygame.draw.rect(screen, MENUBACKGROUND, theme_button_rect)
        pygame.draw.rect(screen, BUTTONLINE, theme_button_rect, 3)

        theme_text = font.render(f"Theme: {theme}", True, FONTCOLOR)
        screen.blit(theme_text, (theme_button_rect.x + 10, theme_button_rect.y + 10))

        # Кнопка смены разрешения
        resolution_button_rect = pygame.Rect(
            screen.get_width() // 2 - button_width // 2,
            screen.get_height() // 2 + 20,
            button_width,
            button_height,
        )
        pygame.draw.rect(screen, MENUBACKGROUND, resolution_button_rect)
        pygame.draw.rect(screen, BUTTONLINE, resolution_button_rect, 3)

        resolution_text = font.render(f"Resolution: {config['current_resolution']}", True, FONTCOLOR)
        screen.blit(resolution_text, (resolution_button_rect.x + 10, resolution_button_rect.y + 10))

        # Обновляем экран
        pygame.display.flip()

    return config


# Основной код
if __name__ == "__main__":
    pygame.init()
    settings = load_settings()

    # Получаем текущие размеры экрана
    current_resolution = settings["resolution"][settings["current_resolution"]]
    screen = pygame.display.set_mode(current_resolution)

    # Открываем меню настроек
    settings = settings_menu(screen, settings)

    pygame.quit()
